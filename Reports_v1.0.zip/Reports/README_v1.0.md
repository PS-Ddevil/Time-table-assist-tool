# Time-table-assist-tool
It is group project under CS308 - Large Applications Practicum course under mentor Dr. Siddartha sharma. </br>
It support checking of conflict arise due to slot, classroom and faculty while making time table of IIT Mandi.

# How to run
Go to the folder and run below command : -

    sudo apt-get install python3-tk
    python3 main.py

# Want to contibute
* Fork the repository into ur account.
* Either work according to the given issues or raise new issue
* Make changes and commit them to user local repository.
* Make a pull request with the details about the changes.

## Documentation
Refer: https://time-table-assist-tool.readthedocs.io/

# Contributer
[Purushottam Sinha](https://github.com/PS-Ddevil) 
[Deepak Kumar](https://github.com/deepakjnv880) 
[Vinay Kumar](https://github.com/vinayskywalker)
[Roshan Sharma](https://github.com/roshan21097) 
